import React from 'react';
import {BrowserRouter, Route, Routes} from "react-router-dom";
import MainPage from "./components/MainPage/MainPage";
import ViewRouteList from "./modules/ViewRouteList/ViewRouteList";
import ViewRoute from "./modules/ViewRoute/ViewRoute";
import ViewReportList from "./modules/ViewReportList/ViewReportList";
import ViewReport from "./modules/ViewReport/ViewReport";
import ViewMain from "./modules/ViewMain/ViewMain";
import ViewEventList from "./modules/ViewEventList/ViewEventList";
import ViewEvent from "./modules/ViewEvent/ViewEvent";
import {readTheme, showTheme, setBackgroundImageRandom} from "./libs/libs";
import ViewInfoList from "./modules/ViewInfoList/ViewInfoList";
import ViewInfo from "./modules/ViewInfo/ViewInfo";
import {AuthProvider} from "./context/AuthContext";
function App() {

  showTheme(readTheme())
  setBackgroundImageRandom()
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<MainPage mainPage={true}/>}>
            <Route path={"/"} element={<ViewMain />} />
          </Route>
          <Route element={<MainPage />}>
            <Route path="/routes" element={<ViewRouteList />}/>
            <Route path="/route/:id" element={<ViewRoute />}/>
            <Route path="/reports" element={<ViewReportList />}/>
            <Route path="/report/:id" element={<ViewReport />}/>
            <Route path="/events" element={<ViewEventList />}/>
            <Route path="/event/:id" element={<ViewEvent />}/>
            <Route path="/infos" element={<ViewInfoList />} />
            <Route path="/info/:id" element={<ViewInfo />}/>
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
