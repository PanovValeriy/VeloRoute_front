import styles from './ViewRouteList.module.css'
import cn from 'classnames'
import {useNavigate, useSearchParams} from "react-router-dom";
import {IRouteListParam, useLazyGetRouteListQuery} from "../../store/services/routeApi";
import React, {useEffect, useMemo, useState} from "react";
import CardList from "../../components/CardList/CardList";
import SearchPanel, {IOnApplySearch} from "../../components/SearchPanel/SearchPanel";
import {routeDefault} from "../../constants";
import Pagination from "../../components/Pagination/Pagination";
import SortPanel from "../../components/SortPanel/SortPanel";
import RouteCard from '../../components/RouteCard/RouteCard';
import Icon from "../../components/Icon/Icon";
import FormModal from "../../components/FormModal/FormModal";

const sortList = [
  {value: 'name', label: 'по возрастанию названия'},
  {value: 'name:desc', label: 'по убыванию названия'},
  {value: 'length', label: 'по возрастанию протяженности'},
  {value: 'length:desc', label: 'по убыванию протяженности'},
  {value: 'dateCreate:desc', label: 'сначала новые'},
  {value: 'dateCreate', label: 'сначала старые'},
]

export default function ViewRouteList() {

  const [showFilter, setShowFilter] = useState<boolean>(false)
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const [getRouteList, {data }] = useLazyGetRouteListQuery()
  const [complexityList, setComplexityList] = useState<{value: number, label: string}[]>([{value: 0, label:'Все'}])
  const param: IRouteListParam = useMemo<IRouteListParam>(() => ({
    page: parseInt(searchParams.get('page') || '1'),
    limit: parseInt(searchParams.get('limit') || routeDefault.limit.toString()),
    search: searchParams.get('search') || '',
    length: searchParams.get('length') || '',
    complexity: parseInt(searchParams.get('complexity') || '0'),
    sort: searchParams.get('sort') || routeDefault.sort,
    showCount: searchParams.get('showCount') || '',
  }),[searchParams])

  function handleChangePage(page: number, pageSize: number) {
    const urlParam: Record<string, any> = new URLSearchParams()
    if (page !== 1 && pageSize === param.limit) {
      urlParam.append('page', page)
    }
    if (pageSize !== routeDefault.limit) {
      urlParam.append('limit', pageSize)
    }
    if (param.search !== '') {
      urlParam.append('search', param.search)
    }
    if (param.length !== '') {
      urlParam.append('length', param.length)
    }
    if (param.complexity !== 0) {
      urlParam.append('complexity', param.complexity)
    }
    if (param.sort !== routeDefault.sort) {
      urlParam.append('sort', param.sort)
    }
    if (param.showCount !== '') {
      urlParam.append('showCount', param.showCount)
    }
    navigate(`/routes?${urlParam}`)
  }

  function handleApplySearch({search='', lengthFrom=0, lengthTo=0, complexity=0} : IOnApplySearch): void {
    const urlParam: Record<string, any> = new URLSearchParams()
    if (param.page !== 1) {
      urlParam.append('page', param.page)
    }
    if (param.limit !== routeDefault.limit) {
      urlParam.append('limit', param.limit)
    }
    if (search !== '') {
      urlParam.append('search', search)
    }
    if (lengthFrom + lengthTo !== 0) {
      urlParam.append('length', `${lengthFrom},${lengthTo}`)
    }
    if (complexity !== 0) {
      urlParam.append('complexity', complexity)
    }
    if (param.sort !== routeDefault.sort) {
      urlParam.append('sort', param.sort)
    }
    if (param.showCount !== '') {
      urlParam.append('showCount', param.showCount)
    }
    navigate(`/routes?${urlParam}`)
  }

  function handleApplySort(sort: string) {
    const urlParam: Record<string, any> = new URLSearchParams()
    if (param.page !== 1) {
      urlParam.append('page', param.page)
    }
    if (param.limit !== routeDefault.limit) {
      urlParam.append('limit', param.limit)
    }
    if (param.search !== '') {
      urlParam.append('search', param.search)
    }
    if (param.length !== '') {
      urlParam.append('length', param.length)
    }
    if (param.complexity !== 0) {
      urlParam.append('complexity', param.complexity)
    }
    if (sort !== routeDefault.sort) {
      urlParam.append('sort', sort)
    }
    if (param.showCount !== '') {
      urlParam.append('showCount', param.showCount)
    }
    navigate(`/routes?${urlParam}`)
  }

  useEffect(() => {
    getRouteList(param)
  }, [getRouteList, param])

  useEffect(() => {
    const cl = [
      {value: 0, label: 'Все'},
      {value: 1, label: 'Легкий'},
      {value: 2, label: 'Средний'},
      {value: 3, label: 'Сложный'},
    ]
    setComplexityList(cl)
  }, [])

  if (!data) {
    return null;
  }
  const lengthFrom = parseInt(param.length?.split(',')[0] || '0')
  const lengthTo = parseInt(param.length?.split(',')[1] || '0')
  const cnRouteFilter = cn(styles.routeFilter, {[styles.showFilter]: showFilter})
  if (param.limit && ((data.recCount !== 0) ? Math.ceil(data.recCount/param.limit) : 1) < (param.page || 1)) {
    handleChangePage((data.recCount !== 0) ? Math.ceil(data.recCount/param.limit) : 1, param.limit)
  }

  return (
    <div className={styles.viewRouteList}>
      <div className={styles.title}>
        <div className={styles.maintitle}><span>Список маршрутов</span><div onClick={() => setShowFilter(true)}><Icon className={styles.buttonFilter} iconName="filter" /></div></div>
        <div className={styles.subtitle}>Находите и выбирайте лучшие веломаршруты для новых приключений</div>
      </div>
      {(showFilter) ? <FormModal onClick={() => setShowFilter(false)} /> : null}
      <div className={cnRouteFilter}>
        <SortPanel options={sortList} value={param.sort} onApply={handleApplySort}/>
        <SearchPanel fields={['search','length', 'complexity']} search={param.search} lengthFrom={lengthFrom} lengthTo={lengthTo} complexityList={complexityList} complexity={param.complexity} onApply={handleApplySearch} onClose={() => setShowFilter(false)} />
      </div>
      <div className={styles.routeList}>
        <CardList>
          {data!.routeList.map((route, idx) => (
            <RouteCard key={idx} route={route} showViews={param.showCount !== ''}/>
          ))}
        </CardList>
        <Pagination current={param.page} pageSize={param.limit} total={data.recCount} hideOnSinglePage={true} onChange={handleChangePage} />
      </div>
    </div>
  )
}