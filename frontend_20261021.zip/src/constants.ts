export const SERVER = 'http://localhost:8000/'
// export const SERVER = '/'

export const API_SERVER = `${SERVER}api/`
export const TOKEN_KEY = 'auth_token';
export const USER_DATA_KEY = 'user_data';

export const routeDefault = {
  limit: 6,
  sort: 'name',
}

export const eventDefault = {
  limit: 6,
  sort: 'startDateTime:desc',
}

export const reportDefault = {
  limit: 9,
  sort: 'date:desc'
}

export const infoDefault = {
  limit: 10,
}

export const backgroundImageList = [
  '/static/back_img_01.jpg',
  '/static/back_img_02.jpg',
  '/static/back_img_03.jpg',
  '/static/back_img_04.jpg',
  '/static/back_img_05.jpg',
  '/static/back_img_06.jpg',
  '/static/back_img_07.jpg',
  '/static/back_img_07.jpg',
  '/static/back_img_08.jpg',
]