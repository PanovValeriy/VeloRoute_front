import styles from './MainPage.module.css'
import {Outlet} from "react-router-dom";
import Header from "./components/Header/Header";
import MenuMobile from "./components/MenuMobile/MenuMobile";
import Login from "../Login/Login";
import {useState} from "react";

interface iProps {
  mainPage?: boolean;
}

export default function MainPage({mainPage}: iProps) {
  // const [showLogin, setShowLogin] = useState(false);

  // function handleShowLogin() {
  //   setShowLogin(true);
  // }

  return (
    <div className={styles.mainPage}>
      <Header mainPage={mainPage}/>
      {/*{(showLogin) ? <Login /> : null}*/}
      <Outlet />
      <MenuMobile className={styles.menuMobile}/>
      <div className={styles.footer}></div>
    </div>
  )
}
