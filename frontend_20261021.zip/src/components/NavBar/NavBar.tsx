import styles from "./NavBar.module.css"
import cn from "classnames"
import {FormEvent, useEffect, useState} from "react"
import { readTheme, toggleTheme } from "../../libs/libs"
import Logo from "../Logo/Logo"
import {Link} from "react-router"
import Menu from "../Menu/Menu"
import FirstEvent from "../FirstEvent/FirstEvent"
import Icon from "../Icon/Icon"
import Login, {ILoginValues} from "../Login/Login";
import {useAuth} from "../../context/AuthContext";
import {getToken} from "../../api/auth";

interface IProps {
  className?: string,
}

interface IError {
  status: number,
  detail: string
}

export default function NavBar({className}: IProps) {
  const cnNavBar = cn(styles.navBar, className)

  // const [getLogin, {data: dataLogin, isLoading: isLoadingLogin, isError: isErrorLogin, isSuccess: isSuccessLogin, error: errorLogin}] = useLazyLoginQuery()
  const {isAuthenticated, login: getLogin, logout: getLogout, isLoading: isLoadingLogin} = useAuth()
  const [theme, setTheme] = useState(readTheme())
  const [showLogin, setShowLogin] = useState(false);
  const [error, setError] = useState('');

  function handleToggleTheme() {
    toggleTheme()
    setTheme(readTheme())
  }

  // function handleLoginOk(data: ILoginValues) {
  //   getLogin(data)
  // }

  function handleClickLogin() {
    if (!isAuthenticated) {
      setShowLogin(true);
    } else {
      getLogout()
      console.log('logout')
    }
  }

  const handleLoginOk = async (data: ILoginValues) => {
    setError('')
    try {
      const d = await getLogin(data.login, data.password)
      setShowLogin(false)
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Неверный логин или пароль'
      setError(message)
    }
  }

  function handleLoginCancel() {
    setShowLogin(false)
  }

  // useEffect(() => {
  //   if (!isLoadingLogin) {
  //     if (isSuccessLogin) console.log('success', dataLogin?.token, dataLogin?.user)
  //     if (isErrorLogin) console.log('error', errorLogin)
  //   }
  // }, [isLoadingLogin, isErrorLogin, isSuccessLogin])

  return (
    <div className={cnNavBar}>
      <Link to={"/"} className={styles.logoLink}><Logo className={styles.logo}/></Link>
      <Menu className={styles.menu} mobile={false}/>
      <div className={styles.rightBlock}>
        <FirstEvent />
        <div className={styles.buttonLogin} onClick={handleClickLogin}>
          <Icon className={styles.buttonLoginIcon} iconName={"user"} />
          <div className={styles.buttonLoginCaption}>{isLoadingLogin ? 'Вход...' : !isAuthenticated ? 'Войти' : 'Выйти'}</div>
        </div>
        <div className={styles.theme} onClick={handleToggleTheme}>
          <Icon className={styles.iconTheme} iconName={ theme === 0 ? "sun" : "moon" } />
        </div>
      </div>
      {(showLogin) ? <Login error={error} onLogin={handleLoginOk} onCancelLogin={handleLoginCancel}/> : null}
    </div>
  )
}