import React, {createContext, useCallback, useContext, useState} from 'react'
import {TOKEN_KEY, USER_DATA_KEY} from "../constants";
import {apiGet, apiLogin, getToken, removeToken, saveToken} from "../api/auth";

export interface IUserData {
  [key: string]: unknown;
  name?: string;
  login?: string;
}

export interface IAuthState {
  user: IUserData | null;
  token: string | null;
}

export interface IAuthContextType {
  user: IUserData | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (login: string, password: string) => Promise<IUserData>;
  logout: () => void;
  updateUser: (userData: IUserData) => void;
}

function getInitialAuthState(): IAuthState {
  const token = getToken()
  const savedUser = localStorage.getItem(USER_DATA_KEY)!;
  return {
    user: token && savedUser ? JSON.parse(savedUser) : null,
    token
  }
}

const AuthContext = createContext<IAuthContextType | null>(null)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<IAuthState>(getInitialAuthState())
  const [isLoading, setIsLoading] = useState<boolean>(false)

  const login = useCallback(async (login: string, password: string): Promise<IUserData> => {
    setIsLoading(true)
    try {
      const data = await apiLogin(login, password)
      const {token, ...userData} = data
      saveToken(token)
      localStorage.setItem(USER_DATA_KEY, JSON.stringify(userData))
      setState({user: userData, token})
      return userData as IUserData
    } finally {
      setIsLoading(false)
    }
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem(USER_DATA_KEY)
    removeToken()
    setState({user: null, token: null})
  }, [])

  const updateUser = useCallback((userData: IUserData) => {
    localStorage.setItem(USER_DATA_KEY, JSON.stringify(userData))
    setState((prev) => ({...prev, user: userData}))
  }, [])

  const value: IAuthContextType = {
    user: state.user,
    token: state.token,
    isAuthenticated: !!state.token,
    isLoading,
    login,
    logout,
    updateUser
  }

  return (
    <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
  )
}

export function useAuth(): IAuthContextType {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within a AuthProvider')
  }
  return context
}

export default AuthContext